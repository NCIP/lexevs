I "fixed" lvg so that I could build a "moveable" version, that doesn't require modifications to the lvg.configuration file when it is deployed.

The changes in this folder are the changes that I made to the source compiled into the "portable" version.


Dan's annotation to this jar from an email follows:

-----Original Message-----
From: Armbrust, Daniel C. [mailto:Armbrust.Daniel@mayo.edu] 
Sent: Wednesday, September 07, 2005 6:55 PM
To: NLM LHC UMLSLEX
Subject: Lvg 2005 improvements

I was very happy to see that the 2005 version of LVG has moved to the HSQL
database.  This mostly cleared that path for me to easily ship LVG as a part
of my applications without any external dependencies or configuration
issues.  However, there are a number of issues remaining with the setup /
initialization of LVG that I would like to see improved in the next version.

The main issue is that the "lvg.properties" file requires an absolute path
for LVG_DIR.  This is should be completely unnecessary in 99% of the use
cases that I can think of, so I have modified the source as appropriate to
eliminate the need for this variable.  My modifications only serve my use
cases, however (using the single string constructors of the java api) and do
not fix it across all of LVG.  I'll leave the rest up to you :)

Basically, I modified the single string constructors for the API classes and
the init methods as appropriate to make it automatically figure out where
LVG is installed based on the location of the configuration file that was
passed in.  This works, as long as the end users don't restructure their LVG
distribution setup.

In the process of removing the dependency on the LVG_DIR property, I
discovered that lvg has the ability to "override" certain properties with
properties provided in a hashtable - however, your override mechanism is
broken.

If you try to pass in a hashtable value for "LVG_DIR" to override the
default from the property file, it will not work because the only way that
overrides work is if every single call to
`Configuration.getConfig("LVG_DIR")` is surrounded by your static method
Configuration.OverWriteProperties(...) - however, you do not call this
method throughout the lvg implementation (see the RamTrie class for an
example) so it ends up being broken.

I fixed this by changing the Configuration class so now you call override
once with a set of override values, and it remembers them and automatically
applies them every time Configuration.getProperty(...) is called.  This also
caused a simplification of the DbBase class, as it no longer needs all of
that override gunk.


I'm attaching a zip file which contains the complete source of the 6 .java
files that I modified, and also a patch file which contains all 6 diffs to
the originals.